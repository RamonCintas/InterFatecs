n = int(input())
print('par' if n % 3 == 0 else 'impar')
