n = int(input())
if n % 3 == 0:
    print('par')
else:
    print('impar')
